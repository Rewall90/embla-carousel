import React from 'react'

const Header: React.FC = () => {
  return (
    <h1 className="header">
      Embla Carousel Loop React
    </h1>
  )
}

export default Header