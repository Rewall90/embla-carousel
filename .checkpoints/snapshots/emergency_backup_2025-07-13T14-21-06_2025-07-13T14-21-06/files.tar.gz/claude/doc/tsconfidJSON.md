{
	"include": [
		"./src/**/*"
	],
	"compilerOptions": {
		"strict": true,
		"esModuleInterop": true,
		"lib": [
			"es6",
			"dom"
		],
		"jsx": "react-jsx"
	}
}