{
	"bracketSpacing": true,
	"printWidth": 80,
	"semi": false,
	"singleQuote": true,
	"trailingComma": "none",
	"tabWidth": 2,
	"useTabs": false
}