'use client'

import { useCallback } from 'react'

interface WheelPhysicsConfig {
  friction: number
  minVelocity: number
  maxSpins: number
  oscillationDamping: number
  oscillationFrequency: number
}

interface PhysicsResult {
  targetIndex: number
  duration: number
  easing: string
}

const DEFAULT_CONFIG: WheelPhysicsConfig = {
  friction: 0.85,
  minVelocity: 0.1,
  maxSpins: 8,
  oscillationDamping: 1.9,
  oscillationFrequency: 0.3
}

export const useWheelPhysics = (slideCount: number, config: Partial<WheelPhysicsConfig> = {}) => {
  const physicsConfig = { ...DEFAULT_CONFIG, ...config }

  const calculatePhysics = useCallback((
    velocity: number,
    currentIndex: number,
    direction: 1 | -1
  ): PhysicsResult => {
    // Convert velocity to momentum (higher velocity = more spins)
    const momentum = Math.abs(velocity) * 10
    
    // Calculate base distance based on momentum
    let distance = momentum * physicsConfig.friction
    
    // Add randomness for realistic wheel behavior
    const randomFactor = 0.3 + Math.random() * 0.4
    distance *= randomFactor
    
    // Ensure minimum movement
    distance = Math.max(distance, 1)
    
    // Limit maximum spins
    distance = Math.min(distance, physicsConfig.maxSpins * slideCount)
    
    // Calculate target index with wrapping
    const rawTarget = currentIndex + (direction * distance)
    const targetIndex = ((Math.round(rawTarget) % slideCount) + slideCount) % slideCount
    
    // Calculate duration based on distance (longer spins take more time)
    // Extended duration for more gradual settling
    const baseDuration = 1200
    const momentumDuration = Math.min(momentum * 250, 4000)
    const settlingTime = 800 + (momentum * 100) // Extra time for oscillation
    const duration = baseDuration + momentumDuration + settlingTime
    
    // Create custom easing that includes oscillation
    // Scale oscillation intensity more gradually with momentum
    const oscillationIntensity = Math.min(momentum * 0.15, 0.8)
    const easing = createOscillatingEasing(oscillationIntensity, physicsConfig, momentum)
    
    return {
      targetIndex,
      duration,
      easing
    }
  }, [slideCount, physicsConfig])

  return { calculatePhysics }
}

function createOscillatingEasing(intensity: number, config: WheelPhysicsConfig, momentum: number): string {
  // Create a gentler cubic-bezier that simulates gradual deceleration with softer overshoot
  // The curve starts fast, slows down gradually, overshoots gently, then settles naturally
  const overshoot = 0.01 + (intensity * 0.05) // Gentler overshoot
  const damping = config.oscillationDamping
  
  // Generate CSS cubic-bezier that creates smoother oscillation effect
  // Adjusted for more natural wheel physics with softer settling
  const p1x = 0.2 // Gentler start
  const p1y = 0.3 + (intensity * 0.2) // More gradual initial curve
  const p2x = 0.7 + (intensity * 0.15) // Softer approach to end
  const p2y = 0.85 + overshoot // Reduced final y for gentler settling
  
  // Ensure values stay within valid cubic-bezier range
  const clampedP2x = Math.min(Math.max(p2x, 0), 1)
  const clampedP2y = Math.min(Math.max(p2y, 0), 1.1) // Allow slight overshoot
  
  return `cubic-bezier(${p1x}, ${p1y}, ${clampedP2x}, ${clampedP2y})`
}